package com.provizit.kioskcheckin.services;

import java.io.Serializable;

public class VcheckuserModel implements Serializable {
    private Integer result;


    public Integer getResult() {
        return result;
    }

    public void setResult(Integer result) {
        this.result = result;
    }


}
