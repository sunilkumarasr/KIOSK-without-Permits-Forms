package com.provizit.kioskcheckin.utilities;

import java.io.Serializable;

public class OidModel implements Serializable {
    private String $oid;

    public String get$oid() {
        return $oid;
    }

    public void set$oid(String $oid) {
        this.$oid = $oid;
    }
}
