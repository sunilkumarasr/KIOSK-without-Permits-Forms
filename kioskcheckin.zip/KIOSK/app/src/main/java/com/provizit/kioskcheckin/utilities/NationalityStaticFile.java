package com.provizit.kioskcheckin.utilities;

public class NationalityStaticFile {

    private String name;
    private String code;

    // Getters
    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
