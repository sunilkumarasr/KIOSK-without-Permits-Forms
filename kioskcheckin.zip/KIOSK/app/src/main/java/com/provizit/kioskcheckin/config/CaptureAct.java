package com.provizit.kioskcheckin.config;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureAct extends CaptureActivity {

}
