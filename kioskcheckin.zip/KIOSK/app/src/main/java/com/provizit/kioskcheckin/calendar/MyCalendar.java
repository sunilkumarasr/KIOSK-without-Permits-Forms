package com.provizit.kioskcheckin.calendar;

public class MyCalendar {
    private String date;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}

