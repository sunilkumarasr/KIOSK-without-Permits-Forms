package com.provizit.kioskcheckin.utilities.WorkPermit;

import java.io.Serializable;

public class CommonObject implements Serializable {

    private String $oid;

    public String get$oid() {
        return $oid;
    }

    public void set$oid(String $oid) {
        this.$oid = $oid;
    }
}
