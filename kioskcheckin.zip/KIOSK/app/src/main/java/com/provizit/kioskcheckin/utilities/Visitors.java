package com.provizit.kioskcheckin.utilities;

import java.io.Serializable;

public class Visitors implements Serializable {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
