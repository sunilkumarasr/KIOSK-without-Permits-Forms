package com.provizit.kioskcheckin.services;

import java.io.Serializable;

public class NdaTime implements Serializable {

    private String $numberLong;

    public String get$numberLong() {
        return $numberLong;
    }

    public void set$numberLong(String $numberLong) {
        this.$numberLong = $numberLong;
    }
}
