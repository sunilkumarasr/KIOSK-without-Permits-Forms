package com.provizit.kioskcheckin.utilities;

import java.io.Serializable;

public class GetCVisitorDetails implements Serializable {


}
