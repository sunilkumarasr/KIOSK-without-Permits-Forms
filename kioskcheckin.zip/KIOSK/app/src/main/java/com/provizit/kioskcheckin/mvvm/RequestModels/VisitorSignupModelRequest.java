package com.provizit.kioskcheckin.mvvm.RequestModels;

import com.google.gson.JsonArray;

public class VisitorSignupModelRequest {
       private JsonArray belongings;
       private String dob;
       private String comp_id;
       private Integer document;
       private JsonArray documents;
       private String email;
       private String formtype;
       private String idnumber;
       private String mobile;
       private String mobilecode;
       private Object mobiledata;
       private Integer mverify;
       private String name;
       private JsonArray other;
       private JsonArray pic;
       private String random;
       private JsonArray vehicles;
       private Integer verify;

}